//
//  FoodFinderApp.swift
//  FoodFinder
//
//  Created by Sarah Si Hui Tan on 18/5/24.
//

import SwiftUI

@main
struct FoodFinderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
